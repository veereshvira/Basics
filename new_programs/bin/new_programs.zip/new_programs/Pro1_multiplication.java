package new_programs;

import java.util.Scanner;

public class Pro1_multiplication {
		public static void main(String[] args) {	
			Scanner sc = new Scanner(System.in);
		/* 	int x,y,sum=0;
			System.out.println("first number");
			x= sc.nextInt();
			System.out.println("second number");
			y=sc.nextInt();
			for(int i=1;i<=x;i++) {
				sum=sum+y;
			}
			System.out.println("The multiplication of "+x+" and "+y+" is: "+sum); 	*/
		System.out.println("first number");
		int x= sc.nextInt();
		System.out.println("second number");
		int y= sc.nextInt();
		int m=0;
		m=x*y;
		System.out.println(m);
		}
	}


